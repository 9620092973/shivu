import React, { Component } from 'react';
import {Form,Button} from 'react-bootstrap';
import './Norm.css';
import { BrowserRouter as Router, Link } from "react-router-dom";


class Norm extends Component {
  render() {
    return (
      <div>
        <Form className="form">
          <Form.Group controlId="formBasicEmail">
            <Form.Label className="email">Email address</Form.Label>
            <Form.Control
              className="place"
              type="email"
              placeholder="Enter email"
            />
          </Form.Group>

          <Form.Group controlId="formBasicPassword">
            <Form.Label className="email">Password</Form.Label>
            <Form.Control
              className="email"
              type="password"
              placeholder="Password"
            />
          </Form.Group>
          <Form.Group controlId="formBasicChecbox">
            <Form.Check type="checkbox" label="Remember Password" />
          </Form.Group>
          <Button variant="primary" type="submit">
            Login
          </Button>
          <Router>
          <Link to="/Register" className="btn btn-link">
            Register
          </Link>
          </Router>
        </Form>
      </div>
    );
  }
}
export default Norm;
